#!/bin/sh
pylint --rcfile=pylint.rc ../bolttools
